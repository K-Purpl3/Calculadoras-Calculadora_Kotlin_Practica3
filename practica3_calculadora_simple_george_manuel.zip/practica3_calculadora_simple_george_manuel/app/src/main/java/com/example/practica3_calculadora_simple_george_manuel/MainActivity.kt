package com.example.practica3_calculadora_simple_george_manuel

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun presionarNumero(view: View){
        val tv_num2: TextView = findViewById(R.id.boton1)
        var num2: String = tv_num2.text.toString()//.toDouble()
        //var num2: Double = tv_num2.text.toString().toDouble()

        //esto es para mostrar los numeros escritos, seguramente no haga ni falta pero ahi esta
        when(view.id){
            R.id.boton0 -> tv_num2.setText(num2 + "0")
            R.id.boton1 -> tv_num2.setText(num2+ "1")
            R.id.boton2 -> tv_num2.setText(num2+ "2")
            R.id.boton3 -> tv_num2.setText(num2+ "3")
            R.id.boton4 -> tv_num2.setText(num2+ "4")
            R.id.boton5 -> tv_num2.setText(num2+ "5")
            R.id.boton6 -> tv_num2.setText(num2+ "6")
            R.id.boton7 -> tv_num2.setText(num2+ "7")
            R.id.boton8 -> tv_num2.setText(num2+ "8")
            R.id.boton9 -> tv_num2.setText(num2+ "9")

        }

    }
}


/*override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContentView(R.layout.activity_main)
    ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
        val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
        insets
    }
}*/